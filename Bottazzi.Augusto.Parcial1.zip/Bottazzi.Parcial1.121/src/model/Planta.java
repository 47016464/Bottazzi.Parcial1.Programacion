package model;

public class Planta {
    String nombre;
    private final String ubicacion;
    private final String clima;

    public Planta(String nombre, String ubicacion, String clima) {
        this.nombre = nombre;
        this.ubicacion = ubicacion;
        this.clima = clima;
    }

    @Override
    public int hashCode() {
        return nombre.hashCode();
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (!(obj instanceof Planta)) return false;
        Planta otra = (Planta) obj;
        return this.nombre.equals(otra.nombre);
    }

    @Override
    public String toString() {
        return "Planta{" + "nombre='" + nombre + "', ubicacion='" + ubicacion + "', clima='" + clima + "'}";
    }
}


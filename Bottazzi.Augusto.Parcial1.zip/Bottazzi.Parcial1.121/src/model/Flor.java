package model;

import enums.Temporada;
import interfaces.DesprenderAroma;
import interfaces.Podable;

public class Flor extends Planta implements DesprenderAroma, Podable {
    private final Temporada temporada;

    public Flor(String nombre, String ubicacion, String clima, Temporada temporada) {
        super(nombre, ubicacion, clima);
        this.temporada = temporada;
    }

    public void desprenderAroma() {
        System.out.println("La flor " + nombre + " desprende su aroma.");
    }

    @Override
    public void podar() {
        System.out.println("Podando flor: " + this);
    }

    @Override
    public String toString() {
        return super.toString() + ", temporada=" + temporada;
    }
}


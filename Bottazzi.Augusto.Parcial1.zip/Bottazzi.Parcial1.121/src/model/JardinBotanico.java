package model;

import enums.Temporada;
import exception.PlantaRepetidaException;
import interfaces.Podable;
import java.util.ArrayList;
import java.util.List;

public class JardinBotanico {
    private final List<Planta> plantas = new ArrayList<>();

    public void agregarPlanta(Planta planta) throws PlantaRepetidaException {
        if (plantas.contains(planta)) {
            throw new PlantaRepetidaException();
        }
        plantas.add(planta);
    }

    public void mostrarPlantas() {
        plantas.forEach(System.out::println);
    }

    public void podarPlantas() {
        for (Planta p : plantas) {
            if (p instanceof Podable podable) {
                podable.podar();
            }
        }
    }

    public void filtrarPorTemporada(Temporada temporada) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}



package model;

import interfaces.DesprenderAroma;
import interfaces.Podable;

public class Arbol extends Planta implements Podable, DesprenderAroma {
    private final int alturaMaxima;

    public Arbol(String nombre, String ubicacion, String clima, int alturaMaxima) {
        super(nombre, ubicacion, clima);
        this.alturaMaxima = alturaMaxima;
    }

    public String getNombre() {
        return nombre;
    }

    @Override
    public void podar() {
        System.out.println("Podando arbol: " + this);
    }

    public void desprenderAroma() {
        System.out.println("El arbol " + nombre + " desprende su aroma.");
    }

    @Override
    public String toString() {
        return super.toString() + ", alturaMaxima=" + alturaMaxima;
    }
}



package exception;

public class PlantaRepetidaException extends Exception {
    private static final String MSG = "La planta ya está en el jardín";

    public PlantaRepetidaException() {
        super(MSG);
    }
}

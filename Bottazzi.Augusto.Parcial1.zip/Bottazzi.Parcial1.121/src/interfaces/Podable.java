package interfaces;

public interface Podable {

    public void podar();
    
}

package interfaces;

public interface DesprenderAroma {
    
    public void DesprenderAroma();
    
}

package interfaces;

public interface DesprenderAroma {
    
}

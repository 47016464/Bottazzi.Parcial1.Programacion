package bottazzi.parcial121;

//import enums.Temporada;
import exception.PlantaRepetidaException;
import model.Arbol;
import model.JardinBotanico;
import model.Planta;

public class BottazziParcial1121 {

    public static void main(String[] args) throws PlantaRepetidaException {
        JardinBotanico jardin = new JardinBotanico();

        //System.out.println(" Agregando Plantas...");
        //Planta roble1 = new Arbol("Roble", "Zona Norte", "Templado", 20);
        //jardin.agregarPlanta(roble1);

        Planta roble2 = new Arbol("Roble", "Zona Norte", "Templado", 25);
        jardin.agregarPlanta(roble2); //(lanza la excepcion)

        System.out.println(" Mostrando todo el registro de plantas... ");
        jardin.mostrarPlantas(); // muestra todas las plantas con sus atributos

        System.out.println(" Realizando poda... ");
        jardin.podarPlantas(); // (solo árboles y arbustos)

        //System.out.println(" Filtrando flores por temporada... ");
        //jardin.filtrarPorTemporada(Temporada.PRIMAVERA);
    }
}

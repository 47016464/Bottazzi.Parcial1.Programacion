package enums;

public enum Temporada {
    PRIMAVERA, VERANO, OTOÑO, INVIERNO;
}
